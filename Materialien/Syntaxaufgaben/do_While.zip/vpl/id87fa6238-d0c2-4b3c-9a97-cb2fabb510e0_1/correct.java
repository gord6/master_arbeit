class Main {
    
    public static void main(String[] args) {
        int[] array = {-2, 9, 20};
        System.out.println(doWhileFunc(array));
    }
    
    static float doWhileFunc(int[] numbers) {
	    int i = 0;
	    int sum = 0;
	    
	    do {
	        sum += numbers[i];
	        i++;
	    } while (i < numbers.length);
	    
	    float average = sum / (float) i;
	    return average;
    }
}