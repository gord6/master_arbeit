class Main {
    
    public static void main(String[] args) {
        doWhileFunc(3);
    }
    
    static void doWhileFunc(int number) {
    	do {
    		System.out.println(number*10);
    		number--;				
    	} while(number > 0);
    }
}