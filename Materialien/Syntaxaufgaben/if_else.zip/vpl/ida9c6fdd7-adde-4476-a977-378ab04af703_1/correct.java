class Main {
    public static void main(String [] args){
        int a = 1;
        int b = 1;
        
        if (a >= b) { 
            System.out.println(a);
        } else {
            System.out.println(b);
        }
    }
}