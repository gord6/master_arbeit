class Main {
    public static void main(String [] args){
        boolean x = false;
        
        if (x == true) { 
            System.out.println("x is true");
         else {
            System.out.println("x is false");
        }
    }
}