class Main {
    public static void main(String [] args){
        int x = 9;
        
        if (x >= 0) { 
            System.out.println("x >= 0");
        } else {
            System.out.println("x < 0");
        }
    }
}