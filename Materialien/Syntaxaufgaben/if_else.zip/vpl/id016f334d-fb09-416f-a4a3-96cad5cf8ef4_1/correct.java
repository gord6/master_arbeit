class Main {
    public static void main(String [] args){
        int a = 0;
        int b = 5;
        
        if (a >= b) { 
            System.out.println("a >= b");
        } else {
            System.out.println("a < b");
        }
    }
}