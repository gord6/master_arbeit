class Main {
    public static void main(String [] args){
        boolean x = true;
        
        if x == true { 
            System.out.println("x is true");
        } else {
            System.out.println("x is false");
        }
    }
}