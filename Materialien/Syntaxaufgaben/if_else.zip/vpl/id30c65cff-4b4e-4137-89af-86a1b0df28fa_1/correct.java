class Main {
    public static void main(String [] args){
        int x = 10;
        
        if (x == 10) { 
            System.out.println("x is 10");
        } else {
            System.out.println("x is not 10");
        }
    }
}