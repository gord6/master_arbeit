class Main {
    public static void main(String [] args){
        int x = 12;
        
        if (x < 10) { 
            System.out.println("x < 10");
        } else {
            System.out.println("x > 20");
        } else if (x >= 10 && x < 20) {
            System.out.println("x >= 10 and x < 20");
        } 
    }
}