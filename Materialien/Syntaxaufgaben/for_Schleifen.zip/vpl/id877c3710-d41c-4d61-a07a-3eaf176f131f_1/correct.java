class Main {
    public static void main(String[] args){
        forFunc();
    }
    
    static void forFunc() {
        for (int i = 1; i<= 10; i++) {
            System.out.println(i);
        }
    }
}