class Main {
    public static void main(String[] args){
        int[] array = {0, 1, 2, 3};
        
        int[] result = forFunc(array);
        
        for (int elem : result){
            System.out.println(elem);
        }
    }
    
    static int [] forFunc(int [] array) {
        for (int i = 0; i < array.length; i++)
            array[i] *= 2;
        }
        
        return array;
    }
}