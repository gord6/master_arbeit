class Main {
    public static void main(String[] args){
        forFunc();
    }
    
    static void forFunc() {
        for (int i = 1; i<= 4; i++) {
            System.out.println(i);
        
    }
}