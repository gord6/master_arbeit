class Main {
    public static void main(String[] args){
        forFunc();
    }
    
    static void forFunc() {
        for (int i=0; i<6; i++) {
		    System.out.print(i + "*2 = ");
	    	for (int j=i; j<=i; j+) {
			    System.out.println(j*2);
		    }
    }
}