class Main {
    public static void main(String[] args){
        System.out.println(forFunc(5));
    }
    
    static int forFunc(int n) {
        int sum = 10;
        
        for (int i = 1; i<= n; i++) {
            sum += i;
        }
    
        return sum;
    }
}