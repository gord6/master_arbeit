class Main {
    public static void main(String[] args){
        forFunc();
    }
    
    static void forFunc() {
        For (int i = 3; i<= 10; i++) {
            System.out.println(i);
        }
    }
}