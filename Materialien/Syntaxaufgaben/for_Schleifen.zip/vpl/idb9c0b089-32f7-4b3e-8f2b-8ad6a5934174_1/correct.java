class Main {
    public static void main(String[] args){
        int [] array = {2, 6, 4, -5};
        forFunc(array);
    }
    
    static void forFunc(int[] array) {
        for (int i = 0; i< array.length; i++){
            System.out.println(array[i]);
        }
    }
}