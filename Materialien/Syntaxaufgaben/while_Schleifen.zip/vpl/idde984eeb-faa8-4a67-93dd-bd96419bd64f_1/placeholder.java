public class Main {
    public static void main (String[] args){
        int [] array = {3, 5, 7, 4};
        whileFunc(array);
    }
    
    static void whileFunc(int[] array) {
        int i = 0;
        
        while i < array.length {
            System.out.println(array[i]);
            i++;
        }
    }
}