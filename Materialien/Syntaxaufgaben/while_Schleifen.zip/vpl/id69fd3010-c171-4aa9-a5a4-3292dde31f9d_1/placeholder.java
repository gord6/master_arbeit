public class Main {
    public static void main (String[] args){
        System.out.println(whileFunc(10));
    }
    
    static int whileFunc(int n) {
        int i = 0;
        int sum = 0;
        
        while (i <= n) 
            sum += i;
            i++;
        }
        return sum;
    }
}