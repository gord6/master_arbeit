public class Main {
    public static void main (String[] args){
        System.out.println(whileFunc(5));
    }
    
    static int whileFunc(int n) {
        int i = 0;
        int sum = 3;
        
        while (i <= n); {
            sum += i;
            i++;
        }
        return sum;
    }
}